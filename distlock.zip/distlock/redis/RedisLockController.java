package com.distlock.redis;

import java.io.Serializable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController  
@RequestMapping("/distribution/redis")  
public class RedisLockController {  
  
    private static final String LOCK_NO = "redis_distribution_lock_no_";  
  
    private static int i = 0;  
  
    private ExecutorService service;  
  
    @Autowired  
    private StringRedisTemplate redisTemplate;  
  
    /** 
     * ģ��1000���߳�ͬʱִ��ҵ���޸���Դ 
     * 
     * ʹ���̳߳ض�����20���߳� 
     * 
     */  
    @GetMapping("lock1")  
    public void testRedisDistributionLock1(){  
  
        service = Executors.newFixedThreadPool(20);  
  
        for (int i=0;i<1000;i++){  
            service.execute(new Runnable() {  
                public void run() {  
                    task(Thread.currentThread().getName());  
                }  
            });  
        }  
  
    }  
    
    
    public static void main(String[] args) {
    	RedisLockController controller = new RedisLockController();
    	controller.testRedisDistributionLock1();
	}
  
    @GetMapping("/{key}")  
    public String getValue(@PathVariable("key") String key){  
        Serializable result = redisTemplate.opsForValue().get(key);  
        return result.toString();  
    }  
  
    private void task(String name) {  
//        System.out.println(name + "����ִ����"+(i++));  
  
        //����һ��redis�ֲ�ʽ��  
        RedisLockImpl redisLock = new RedisLockImpl(redisTemplate);  
        //����ʱ��  
        Long lockTime;  
        if ((lockTime = redisLock.lock((LOCK_NO+1)+"", name))!=null){  
            //��ʼִ������  
            System.out.println(name + "����ִ����"+(i++));  
            //����ִ����� �ر���  
            redisLock.unlock((LOCK_NO+1)+"", lockTime, name);  
        }  
  
    }  
}  