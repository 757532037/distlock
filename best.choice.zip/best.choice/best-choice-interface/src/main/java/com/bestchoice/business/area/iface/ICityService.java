package com.bestchoice.business.area.iface;

import java.util.List;

import com.bestchoice.business.area.model.Area;
import com.bestchoice.business.area.model.City;
import com.bestchoice.business.area.model.Province;

public interface ICityService {

	public List<Province> getAllProvince();

    public List<City> getCityByProvinceId(String id);

    public List<Area> getAreaByCityId(String id);
    
    public List<Province> getAllProvince_oracle();

    public List<City> getCityByProvinceId_oracle(String id);

    public List<Area> getAreaByCityId_oracle(String id);
	
    public String getProByNum(String num); 
    public String getProByNumzk(String num)throws Exception; 
}

