package com.bestchoice.business.zybank.service;

public interface IstudentService {

	public String getStudentNameById(String stuId);
	
}
