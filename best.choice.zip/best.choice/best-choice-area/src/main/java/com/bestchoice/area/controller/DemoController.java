package com.bestchoice.area.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.bestchoice.business.area.iface.ICityService;
import com.bestchoice.business.area.model.Area;
import com.bestchoice.business.area.model.City;
import com.bestchoice.util.Json;

/**
 * Created with Intellij IDEA.
 * User: wesley
 * Date: 2015/4/16
 * Time: 18:05
 */
@Controller
public class DemoController {

    @Autowired
    private ICityService cityService;

    /**
     * 棣栧厛鑾峰彇鍏ㄩ儴鐨勭渷浠�
     * @param map
     * @return
     */
    @RequestMapping(value="/index")
    public String allProvince(ModelMap map){
        map.addAttribute("provinceList", cityService.getAllProvince());
        return "index.jsp";
    }

    /**
     * 鏍规嵁鐪佷唤鑾峰彇鍩庡競
     * @param id
     * @return
     */
    @RequestMapping(value = "/getCityByProvinceId/{id}")
    @ResponseBody
    public Json getCityByProvinceId(@PathVariable("id") String id){
        List<City> cityList = cityService.getCityByProvinceId(id);
        if (cityList!=null){
            return new Json(true,"success",cityList);
        } else {
            return new Json(false,"fail",null);
        }
    }

    /**
     * 鏍规嵁鍩庡競鑾峰彇鍖哄煙
     * @param id
     * @return
     */
    @RequestMapping(value = "/getAreaByCityId/{id}")
    @ResponseBody
    public Json getAreaByCityId(@PathVariable("id") String id){
        List<Area> areaList = cityService.getAreaByCityId(id);
        if (areaList!=null){
            return new Json(true,"success",areaList);
        } else {
            return new Json(false,"fail",null);
        }
    }
    
    /********************************************split beautiful*************************************************/
    
    /**
     * 棣栧厛鑾峰彇鍏ㄩ儴鐨勭渷浠�
     * @param map
     * @return
     */
    @RequestMapping(value="/index_oracle")
    public String allProvince_oracle(ModelMap map){
        map.addAttribute("provinceList", cityService.getAllProvince_oracle());
        return "index_oracle.jsp";
    }

    /**
     * 鏍规嵁鐪佷唤鑾峰彇鍩庡競
     * @param id
     * @return
     */
    @RequestMapping(value = "/getCityByProvinceId_oracle/{id}")
    @ResponseBody
    public Json getCityByProvinceId_oracle(@PathVariable("id") String id){
        List<City> cityList = cityService.getCityByProvinceId_oracle(id);
        if (cityList!=null){
            return new Json(true,"success",cityList);
        } else {
            return new Json(false,"fail",null);
        }
    }

    /**
     * 鏍规嵁鍩庡競鑾峰彇鍖哄煙
     * @param id
     * @return
     */
    @RequestMapping(value = "/getAreaByCityId_oracle/{id}")
    @ResponseBody
    public Json getAreaByCityId_oracle(@PathVariable("id") String id){
        List<Area> areaList = cityService.getAreaByCityId_oracle(id);
        if (areaList!=null){
            return new Json(true,"success",areaList);
        } else {
            return new Json(false,"fail",null);
        }
    }
    
    @ResponseBody
    @RequestMapping(value="/lockTest")
    public Json lockTest(String num){
    	try {
			Thread.sleep(20000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	System.out.println("开始执行...");
    	return new Json(true,cityService.getProByNum(num),num) ;
    }
    
    
    
}
