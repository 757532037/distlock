package com.bestchoice.area.controller.test;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CountDownLatch;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.bestchoice.business.area.iface.ICityService;


@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("classpath:/spring-context.xml")
public class testredisLock {
	
	@Autowired
    private ICityService cityService;
	
	@Test
	public void testredis() throws InterruptedException {
	//	System.out.println(1+"ȡ��״̬:\t"+cityService.getProByNum("2"));
	//	System.out.println(1+"ȡ��״̬:\t"+cityService.getProByNum("3"));
	//	System.out.println(1+"ȡ��״̬:\t"+cityService.getProByNum("1"));
	//	System.out.println(1+"ȡ��״̬:\t"+cityService.getProByNum("2"));
	//	System.out.println(1+"ȡ��״̬:\t"+cityService.getProByNum("1"));
	//	System.out.println(1+"ȡ��״̬:\t"+cityService.getProByNum("3"));
	//	System.out.println(1+"ȡ��״̬:\t"+cityService.getProByNum("1"));
		
		
		for(int i=0;i<2010;i++){
			System.out.println(""+i);
			myThread thread = new myThread( cityService, "1");
			thread.start();
		}
		System.out.println("*******************");
		try {
			Thread.sleep(10000000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

//		int count = 5;
//		final String proNum = "1";
//		for(int i=0;i<count;i++){
//			final ICityService service = cityService;
//			 new Thread(new Runnable(){
//				
//				@Override
//				public void run() {
//					// TODO Auto-generated method stub
//					System.out.println("׼������..."+Thread.currentThread().getName());
//					System.out.println(proNum+"ȡ��״̬:\t"+service.getProByNum(proNum));
//				}
//			},"mythread-"+i).start();
//		}
//		 
//		try {
//			System.out.println("222222");
//			Thread.sleep(100000);
//			System.out.println("333333");
//		} catch (InterruptedException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}

	
	}
	
	class myThread extends Thread{
		CountDownLatch countDownLatch;
		ICityService cityService;
		String num;
		public myThread(ICityService cityService,String num ) {
			// TODO Auto-generated constructor stub
//			this.countDownLatch = countDownLatch;
			System.out.println("***************/");
			this.cityService = cityService;
			this.num = num;
		}
		
		@Override
		public void run(){
			System.out.println(num+"ȡ��״̬:\t"+cityService.getProByNum(num));
			try {
//				System.out.println(num+"ȡ��״̬:\t"+cityService.getProByNumzk(num));
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}

}
