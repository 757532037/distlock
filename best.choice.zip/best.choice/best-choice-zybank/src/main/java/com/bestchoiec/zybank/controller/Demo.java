package com.bestchoiec.zybank.controller;

import java.io.IOException;

import javax.websocket.OnClose;
import javax.websocket.OnError;
import javax.websocket.OnMessage;
import javax.websocket.OnOpen;
import javax.websocket.server.PathParam;
import javax.websocket.server.ServerEndpoint;

import com.shpoints.util.EncodeUtil;

/**
 * 
 * @ClassName: AuthController 
 * @Description: TODO
 * @author xf.hu
 * @date 2017�?4�?25�? 下午1:09:35 
 *
 */
@ServerEndpoint("/demo/my")
public class Demo {
	
	@OnMessage
	public void onMessage(String message, javax.websocket.Session session) throws IOException {
		String recMsg = "server received:" + message + "\tid:[%s]";
		System.out.println(String.format(recMsg, session.getId()));
		String imgMsg = "<img alt=\"\" src=\"http://p0.ifengimg.com/pmop/2017/0627/A271E994E1B6AFBEE8DA06845B3FFE6801AA8FF1_size28_w632_h277.jpeg\">";
		session.getBasicRemote().sendText(imgMsg);
	}
	
	@OnOpen
	public void onOpen(javax.websocket.Session session) {
		String recMsg = "server onOpen:\tid:[%s]";
		System.out.println(String.format(recMsg, session.getId()));
	}
	
	@OnClose
	public void onClose(javax.websocket.Session session) {
		String recMsg = "server onClose:\tid:[%s]";
		System.out.println(String.format(recMsg, session.getId()));
	}
	
	@OnError
	public void onError(@PathParam(value = "error") Throwable error,javax.websocket.Session session) {
		String recMsg = "server onError:\tid:[%s]\t";
		System.out.println(String.format(recMsg,session.getId())+error.getMessage());
	}
	
	public static void main(String[] args) {
		
		String s = "a%sc%c";
		System.out.println(String.format(s, "b",'d'));
		
		byte[] bt1 = "I LOVE CHINA".getBytes();
		String hex = EncodeUtil.hex(bt1);
		System.out.println(hex);
		
//		byte[] bts = EncodeUtil.binary("FFFFFEFCFFFA");
//		System.out.println(new String(bts));
//		System.out.println(EncodeUtil.binary(hex));
//		System.out.println(EncodeUtil.binary(bt));
//		System.out.println(EncodeUtil.hex(bt));
//		System.out.println(EncodeUtil.binary(bt));
		System.out.println(new String(bt1));
		
		byte[] bt2 = EncodeUtil.bcd(hex);
		System.out.println(new String(bt2));
		System.out.println(EncodeUtil.hex(bt2));
		System.out.println(bt1==bt2);
		
	}

}
