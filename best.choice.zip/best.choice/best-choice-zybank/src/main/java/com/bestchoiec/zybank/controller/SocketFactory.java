package com.bestchoiec.zybank.controller;

import java.util.ArrayList;

public class SocketFactory {

	
	
	static final java.util.List<javax.websocket.Session> SOCKETLIST = new ArrayList<javax.websocket.Session>();
	
	
}
