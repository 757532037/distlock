package com.distlock.zk.curator;

import java.util.Arrays;
import java.util.Date;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

import locking.FakeLimitedResource;

import org.apache.curator.framework.CuratorFramework;
import org.apache.curator.framework.CuratorFrameworkFactory;
import org.apache.curator.framework.recipes.locks.InterProcessLock;
import org.apache.curator.framework.recipes.locks.InterProcessMultiLock;
import org.apache.curator.framework.recipes.locks.InterProcessMutex;
import org.apache.curator.framework.recipes.locks.InterProcessSemaphoreMutex;
import org.apache.curator.retry.ExponentialBackoffRetry;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class InterProcessMultiLockExample
{
//	static CountDownLatch count;
	public InterProcessMultiLockExample(CountDownLatch count){
		this(count,null);
	}
	InterProcessMultiLockExample(CountDownLatch count,String s){
//		this.count = count;
	}
	
    private static final String PATH1 = "/examples/locks1";
    private static final String PATH2 = "/examples/locks2";
    public static void mains(CuratorFramework client) throws Exception
    {
        FakeLimitedResource resource = new FakeLimitedResource();
        InterProcessLock lock1 = new InterProcessMutex(client, PATH1); // ��������
        InterProcessLock lock2 = new InterProcessSemaphoreMutex(client, PATH2); // ����������
        InterProcessMultiLock lock = new InterProcessMultiLock(Arrays.asList( lock2));
        if (!lock.acquire(30, TimeUnit.SECONDS))
        {
        	log.error("��ǰϵͳ��æ�����ܻ�ȡ����");
            throw new IllegalStateException("��ǰϵͳ��æ�����ܻ�ȡ����");
        }
        log.info("�ѻ�ȡ����");
        log.info("�Ƿ��е�һ����: " + lock1.isAcquiredInThisProcess());
        log.info("�Ƿ��еڶ�����: " + lock2.isAcquiredInThisProcess());
        try
        {
            resource.use(); // ��Դ����
            log.error(""+System.currentTimeMillis());
            log.info(new Date().toLocaleString()+"\t7");
//            Thread.sleep(9000);
            log.error(""+System.currentTimeMillis());
            log.info(new Date().toLocaleString()+"\t8");
        }
        finally
        {
//            log.info("�ͷŶ����"+count.getCount());
            lock.release(); // �ͷŶ���
//            count.countDown();
            
        }
        log.info("�Ƿ��е�һ����: " + lock1.isAcquiredInThisProcess());
        log.info("�Ƿ��еڶ�����: " + lock2.isAcquiredInThisProcess());
        log.info("OK!");
    }
    
    
	private static final Logger log = LoggerFactory.getLogger(InterProcessMultiLockExample.class);

    public static void main(String[] args) throws Exception
    {
//    	log.info(1499739322009l-1499739322083l);
//    	log.info(1499739404040l-1499739404123l);
//    	log.info(1499739467823l-1499739467904l);
//    	log.info(1499740072779l-1499740072860l);
//    	log.info(1499740081860l-1499740081950l); 
//    	log.info(1499740090951l-1499740100100l);
//    	log.info(1499740109100l-1499740091034l);
    	
//    	int thdSize = 10;
//    	java.util.concurrent.BlockingQueue<Thread> runQueue = new ArrayBlockingQueue<Thread>(thdSize);
//    	for(int thd=0;thd<thdSize;thd++){
//    		Thread td1 = new Thread(new Runnable(){
//
//				public void run() {
					// TODO Auto-generated method stub
					long start_time = System.currentTimeMillis();
					CuratorFramework client = CuratorFrameworkFactory.newClient("192.168.0.223:2181", new ExponentialBackoffRetry(1000, 3));
			        client.start();
			    	int threadSize = 1000;
//			    	CountDownLatch count = new CountDownLatch(threadSize);
			    	for(int i=0;i<threadSize;i++){
			    		InterProcessMultiLockExample inter = new InterProcessMultiLockExample(null);
			    		try {
							inter.mains(client);
						} catch (Exception e) {
							// TODO Auto-generated catch block27313
							e.printStackTrace();
						}
			    		
			    	}
//			    	try {
//						count.await();
//					} catch (InterruptedException e) {
//						// TODO Auto-generated catch block
//						e.printStackTrace();
//					}
			    	client.close();
			    	log.info("end!"+(System.currentTimeMillis()-start_time));
//				}
    			
//    		},"MyThread:\t"+thd);
//    		runQueue.add(td1);
//    	}
//    	
//    	
//    	for(int thd=0;thd<thdSize;thd++){
//    		Thread thid = runQueue.poll();
//    		thid.start();
//    	}

    }
}