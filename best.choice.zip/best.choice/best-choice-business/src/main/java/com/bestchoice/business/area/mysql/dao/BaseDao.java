package com.bestchoice.business.area.mysql.dao;

import java.util.List;
import java.util.Map;

/**
 * Created with Intellij IDEA.
 * User: wesley
 * Date: 2015/3/5
 * Time: 18:00
 * 涓�浜涘叕鐢ㄧ殑鏂规硶
 */
public interface BaseDao<T> {
    /**
     * 鎻掑叆涓�鏉¤褰�
     *
     * @param t
     */
    public void insert(T t);

    /**
     * 鏍规嵁Id鍒犻櫎涓�鏉¤褰�
     *
     * @param id
     */
    public void deleteById(String id);

    /**
     * 鏇存柊涓�鏉¤褰�
     *
     * @param t
     */
    public void update(T t);

    /**
     * 鏍规嵁Id鏌ヨ涓�鏉¤褰�
     *
     * @param id
     * @return
     */
    public T selectById(String id);

    /**
     * 鍒楀嚭鎵�鏈夎褰�
     *
     * @return
     */
    public List<T> list();

    /**
     * 鏌ヨ璁板綍鏉℃暟
     *
     * @return
     */
    public long count(Map<String, Object> map);

    /**
     * 鎸夌収鏉′欢鏌ヨ
     *
     * @return
     */
    public List<T> find(Map<String, Object> map);
}
