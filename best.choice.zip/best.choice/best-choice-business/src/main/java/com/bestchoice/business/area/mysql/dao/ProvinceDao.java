package com.bestchoice.business.area.mysql.dao;

import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import com.bestchoice.business.area.model.Province;


/**
 * Created with Intellij IDEA.
 * User: wesley
 * Date: 2015/4/16
 * Time: 18:02
 */

public interface ProvinceDao extends BaseDao<Province>{
	
	@Select("select sum(red.gnu) from quanbank.red_hat red where 1=1;")
	public abstract String selectLessProNum(@Param("num") String num);
	
	@Update("update quanbank.red_hat red set red.gnu = red.gnu-#{num} where 1=1")
	public abstract int updateProLess(@Param("num") Integer num);
	
}