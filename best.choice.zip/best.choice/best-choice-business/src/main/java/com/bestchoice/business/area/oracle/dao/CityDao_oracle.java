package com.bestchoice.business.area.oracle.dao;

import java.util.List;

import org.springframework.stereotype.Service;

import com.bestchoice.business.area.model.City;

/**
 * Created with Intellij IDEA.
 * User: wesley
 * Date: 2015/4/16
 * Time: 18:02
 */
public interface CityDao_oracle extends BaseDao_oracle<City>{
    public List<City> getCityByProvinceId_oracle(String id);
}