package com.bestchoice.business.area.oracle.dao;

import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;
import org.springframework.stereotype.Service;

import com.bestchoice.business.area.model.Province;


/**
 * Created with Intellij IDEA.
 * User: wesley
 * Date: 2015/4/16
 * Time: 18:02
 */
public interface ProvinceDao_oracle extends BaseDao_oracle<Province>{
	
}