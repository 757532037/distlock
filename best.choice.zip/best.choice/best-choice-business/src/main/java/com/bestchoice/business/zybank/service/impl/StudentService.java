package com.bestchoice.business.zybank.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bestchoice.business.zybank.service.IstudentService;
import com.bestchoice.distrblock.redis.lock.RedisLock;

@Service("studentService")
public class StudentService implements IstudentService{

	@Autowired
	RedisLock redisLock;
	
	
	public String getStudentNameById(String stuId) {
		// TODO Auto-generated method stub
		
		try {
			redisLock.lock();
			return stuId+":"+System.currentTimeMillis();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			redisLock.unlock();
		}finally{
			redisLock.unlock();
		}
		return stuId+":"+System.currentTimeMillis();
		
	}

}
