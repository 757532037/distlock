package com.bestchoice.business.area.oracle.dao;



import java.util.List;

import org.springframework.stereotype.Service;

import com.bestchoice.business.area.model.Area;

/**
 * Created with Intellij IDEA.
 * User: wesley
 * Date: 2015/4/16
 * Time: 18:02
 */
public interface AreaDao_oracle extends BaseDao_oracle<Area>{

    public List<Area> getAreaByCityId_oracle(String id);
}