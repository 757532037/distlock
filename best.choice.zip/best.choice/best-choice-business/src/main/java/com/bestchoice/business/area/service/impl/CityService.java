package com.bestchoice.business.area.service.impl;


import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

import locking.FakeLimitedResource;

import org.apache.curator.framework.CuratorFramework;
import org.apache.curator.framework.CuratorFrameworkFactory;
import org.apache.curator.framework.recipes.locks.InterProcessLock;
import org.apache.curator.framework.recipes.locks.InterProcessMultiLock;
import org.apache.curator.framework.recipes.locks.InterProcessSemaphoreMutex;
import org.apache.curator.retry.ExponentialBackoffRetry;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bestchoice.business.area.iface.ICityService;
import com.bestchoice.business.area.model.Area;
import com.bestchoice.business.area.model.City;
import com.bestchoice.business.area.model.Province;
import com.bestchoice.business.area.mysql.dao.AreaDao;
import com.bestchoice.business.area.mysql.dao.CityDao;
import com.bestchoice.business.area.mysql.dao.ProvinceDao;
import com.bestchoice.distrblock.redis.lock.RedisLock;


/**
 * Created with Intellij IDEA.
 * User: wesley
 * Date: 2015/4/16
 * Time: 18:03
 * 鏈夊叧鍩庡競鍖虹殑鏈嶅姟灞�
 */
@Service
public class CityService implements ICityService{

    @Autowired
    private CityDao cityDao;
    @Autowired
    private ProvinceDao provinceDao;
    @Autowired
    private AreaDao areaDao;

    public List<Province> getAllProvince() {
        return provinceDao.list();
    }

    public List<City> getCityByProvinceId(String id) {
        return cityDao.getCityByProvinceId(id);
    }

    public List<Area> getAreaByCityId(String id) {
        return areaDao.getAreaByCityId(id);
    }

    @Autowired
    private com.bestchoice.business.area.oracle.dao.CityDao_oracle cityDao_oracle;
    @Autowired
    private com.bestchoice.business.area.oracle.dao.ProvinceDao_oracle provinceDao_oracle;
    @Autowired
    private com.bestchoice.business.area.oracle.dao.AreaDao_oracle areaDao_oracle;
    
	public List<Province> getAllProvince_oracle() {
		// TODO Auto-generated method stub
		return provinceDao_oracle.list();
	}

	public List<City> getCityByProvinceId_oracle(String id) {
		// TODO Auto-generated method stub
		return cityDao_oracle.getCityByProvinceId_oracle(id);
	}

	public List<Area> getAreaByCityId_oracle(String id) {
		// TODO Auto-generated method stub
		return areaDao_oracle.getAreaByCityId_oracle(id);
	}

	@Autowired
	RedisLock redisLock;
	public String getProByNum(String num) {
		// TODO Auto-generated method stub
		String status = "fail";
		while(true){
			try {
			synchronized (this) {
			
				if(redisLock.lock()){
					System.out.println("lock...");
					String allNum = provinceDao.selectLessProNum(num);
					if(Integer.parseInt(allNum)>=Integer.parseInt(num)){
						System.out.println("请求库存"+num+"剩余库存"+allNum+"产品充足!!!");
						int updatestatu = provinceDao.updateProLess(Integer.parseInt(num));
						status= "success";
					}else{
						System.out.println("请求库存"+num+"剩余库存"+allNum+"产品不充足!!!");
						status= "fail";
					}
					System.out.println("unlock...");
					redisLock.unlock();
					break;
				}
			}
			Thread.sleep(10);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				redisLock.unlock();
			} 
			
		}
				
			//redisLock.unlock();
		
		return status;
	}
	
	
	public String getProByNumzk(String num) throws Exception {
		String status = "fail";
		FakeLimitedResource resource = new FakeLimitedResource();
		CuratorFramework client = CuratorFrameworkFactory.newClient("192.168.0.223:2181", new ExponentialBackoffRetry(1000, 3));
        client.start();
      InterProcessLock lock2 = new InterProcessSemaphoreMutex(client, "/examples/locks2"); // 不可重入锁
      InterProcessMultiLock lock = new InterProcessMultiLock(Arrays.asList( lock2));
      if (!lock.acquire(30, TimeUnit.SECONDS))
      {
          throw new IllegalStateException("当前系统繁忙，不能获取多锁");
      }
      try
      {
          resource.use(); // 资源操作
          System.out.println("lock...");
			String allNum = provinceDao.selectLessProNum(num);
			if(Integer.parseInt(allNum)>=Integer.parseInt(num)){
				System.out.println("请求库存"+num+"剩余库存"+allNum+"产品充足!!!");
				int updatestatu = provinceDao.updateProLess(Integer.parseInt(num));
				System.out.println("updatestatu:\t"+updatestatu);
				status= "success";
			}else{
				System.out.println("请求库存"+num+"剩余库存"+allNum+"产品不充足!!!");
				status= "fail";
			}
			System.out.println("unlock...");
      }
      finally
      {
          lock.release(); // 释放多锁
          client.close();
      }
      
		return status;
	}
	
}
